package com.example.stopwatch;

public class MainActivity2 {
}
